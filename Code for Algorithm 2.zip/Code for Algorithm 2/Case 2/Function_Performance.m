function [I,Performance] = Function_Performance(Initial_inventory_cost,Trans_cost,T,N,C,ch,cp,q,I0,d)

Performance = zeros(1);  
I = zeros(T,N);
Inventory_at_start_period = zeros(T,N); 

for i = 1:1:N 
    if I0(i) + q(1,i) > C(i) 
       Inventory_at_start_period(1,i) = C(i); 
    else  
       Inventory_at_start_period(1,i) = I0(i) + q(1,i);
    end 
	I(1,i) = Inventory_at_start_period(1,i) - d(1,i); 
end 

for t = 2:1:T 
    for i = 1:1:N   
        if I(t-1,i) + q(t,i) > C(i) 
           Inventory_at_start_period(t,i) = C(i); 
        else  
           Inventory_at_start_period(t,i) = I(t-1,i) + q(t,i);
        end
	    I(t,i) = Inventory_at_start_period(t,i) - d(t,i);    
    end
end
 
%% 
for t = 1:1:T
    for i = 1:1:N 
        if (I(t,i) > 0 && I(t,i) <= C(i)) 
			Performance = Performance + ch(i) * I(t,i); 
        end 
        
        if (I(t,i) > 0 && I(t,i) > C(i)) 
			I(t,i) = C(i); 
            Performance = Performance + ch(i) * I(t,i);
        end
 
        if (I(t,i) < 0) 
			Performance = Performance - cp(i) * I(t,i); 
        end
    end
end
Performance = Performance + Initial_inventory_cost + Trans_cost;

end
