%% Parameter
Period = 3;     
Retailer = 10;    
I0 = xlsread('Experimental_data.xlsx','Data','B3:K3');             
C = xlsread('Experimental_data.xlsx','Data','B7:K7');             
t1_max_Demand = xlsread('Experimental_data.xlsx','Data','B11:K11');   
t1_min_Demand = xlsread('Experimental_data.xlsx','Data','B17:K17');  
t2_max_Demand = xlsread('Experimental_data.xlsx','Data','B12:K12');   
t2_min_Demand = xlsread('Experimental_data.xlsx','Data','B18:K18');    
t3_max_Demand = xlsread('Experimental_data.xlsx','Data','B13:K13');   
t3_min_Demand = xlsread('Experimental_data.xlsx','Data','B19:K19');   
ch = xlsread('Experimental_data.xlsx','Data','B23:K23');         
cp = xlsread('Experimental_data.xlsx','Data','B27:K27');           
Initial_inventory_cost = sum(I0.*cp);  
%%    
GDRO_Trans_Cost = xlsread('Experimental_data.xlsx','Data','F30'); 
DRO_Trans_Cost = xlsread('Experimental_data.xlsx','Data','I30'); 
SAA_Trans_Cost = xlsread('Experimental_data.xlsx','Data','L30'); 
Deter_Trans_Cost = xlsread('Experimental_data.xlsx','Data','O30'); 
 
GDRO_Q = xlsread('Experimental_data.xlsx','Data','B38:K40'); 
DRO_Q = xlsread('Experimental_data.xlsx','Data','B43:K45'); 
SAA_Q = xlsread('Experimental_data.xlsx','Data','B48:K50');          
Deter_Q = xlsread('Experimental_data.xlsx','Data','B53:K55');

GDRO_tau = xlsread('Experimental_data.xlsx','Data','B61:K61'); 
DRO_tau = xlsread('Experimental_data.xlsx','Data','B64:K64'); 
SAA_tau = xlsread('Experimental_data.xlsx','Data','B67:K67'); 
Deter_tau = xlsread('Experimental_data.xlsx','Data','B70:K70'); 

%% 
Theta = 0.2;     
Size = 3000;    
Demand_data_set = zeros(Period,Retailer);    

%% 
GDRO_Performance = zeros(Size,1);
DRO_Performance = zeros(Size,1); 
SAA_Performance = zeros(Size,1);
Deter_Performance = zeros(Size,1);

GDRO_Shortage_Count = zeros(1);
DRO_Shortage_Count = zeros(1); 
SAA_Shortage_Count = zeros(1);
Deter_Shortage_Count = zeros(1);

GDRO_Violation_Count = zeros(1);
DRO_Violation_Count = zeros(1); 
SAA_Violation_Count = zeros(1);
Deter_Violation_Count = zeros(1);

GDRO_Violate_MLP_Count = zeros(1);
DRO_Violate_MLP_Count = zeros(1); 
SAA_Violate_MLP_Count = zeros(1);
Deter_Violate_MLP_Count = zeros(1);

GDRO_Violate_MIC_Count = zeros(1);
DRO_Violate_MIC_Count = zeros(1); 
SAA_Violate_MIC_Count = zeros(1);
Deter_Violate_MIC_Count = zeros(1);

%%  
for s = 1:1:Size   
    for j = 1:1:Retailer
        t1_a = 3;
        t1_b = 2; 
        Demand_data_set(1,j) = fix( (t1_max_Demand(j)*(1+Theta) - t1_min_Demand(j)*(1-Theta)) .* betarnd(t1_a, t1_b) + t1_min_Demand(j)*(1-Theta) );
        
        t2_a = 3; 
        t2_b = 2; 
        Demand_data_set(2,j) = fix( (t2_max_Demand(j)*(1+Theta) - t2_min_Demand(j)*(1-Theta)) .* betarnd(t2_a, t2_b) + t2_min_Demand(j)*(1-Theta) );
        
        t3_a = 3;
        t3_b = 2; 
        Demand_data_set(3,j) = fix( (t3_max_Demand(j)*(1+Theta) - t3_min_Demand(j)*(1-Theta)) .* betarnd(t3_a, t3_b) + t3_min_Demand(j)*(1-Theta) );
    end
    
    [GDRO_I,GDRO_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,GDRO_Trans_Cost,Period,Retailer,C,ch,cp,GDRO_Q,I0,Demand_data_set);
    [DRO_I,DRO_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,DRO_Trans_Cost,Period,Retailer,C,ch,cp,DRO_Q,I0,Demand_data_set);
    [SAA_I,SAA_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,SAA_Trans_Cost,Period,Retailer,C,ch,cp,SAA_Q,I0,Demand_data_set); 
    [Deter_I,Deter_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,Deter_Trans_Cost,Period,Retailer,C,ch,cp,Deter_Q,I0,Demand_data_set);
    
    for t = 1:1:Period
        for j = 1:1:Retailer 
            if GDRO_I(t,j) < 0.01
               GDRO_Shortage_Count = GDRO_Shortage_Count + 1; 
            end
            if DRO_I(t,j) < 0.01
               DRO_Shortage_Count = DRO_Shortage_Count + 1; 
            end
            if SAA_I(t,j) < 0.01
               SAA_Shortage_Count = SAA_Shortage_Count + 1; 
            end
            if Deter_I(t,j) < 0.01
               Deter_Shortage_Count = Deter_Shortage_Count + 1; 
            end
        end 
    end
    
    for j = 1:1:Retailer
        [GDRO_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),GDRO_Q(:,j),I0(j),Demand_data_set(:,j),GDRO_tau(j));
        [DRO_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),DRO_Q(:,j),I0(j),Demand_data_set(:,j),DRO_tau(j));
        [SAA_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),SAA_Q(:,j),I0(j),Demand_data_set(:,j),SAA_tau(j));
        [Deter_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),Deter_Q(:,j),I0(j),Demand_data_set(:,j),Deter_tau(j));    
        
        if GDRO_Result == 1
            GDRO_Violation_Count = GDRO_Violation_Count + 1; 
        end   
        if DRO_Result == 1
            DRO_Violation_Count = DRO_Violation_Count + 1; 
        end  
        if SAA_Result == 1
            SAA_Violation_Count = SAA_Violation_Count + 1; 
        end
        if Deter_Result == 1
            Deter_Violation_Count = Deter_Violation_Count + 1; 
        end   
    end 
   
end 

GDRO_Per = sort(GDRO_Performance);
DRO_Per = sort(DRO_Performance);  
SAA_Per = sort(SAA_Performance);  
Deter_Per = sort(Deter_Performance);

Performance = cell(5,9); 

Performance{1,2} = "Minimum";
Performance{1,3} = "25th %";
Performance{1,4} = "Average";
Performance{1,5} = "75th %";
Performance{1,6} = "Maximum";
Performance{1,7} = "Shortage_Rate";
Performance{1,8} = "Budget_Valation_Rate";
Performance{1,9} = "CVaR";
Performance{2,1} = "GDRO_IRP_Per";
Performance{3,1} = "DRO_IRP_Per";
Performance{4,1} = "SAA_IRP_Per";  
Performance{5,1} = "Deter_IRP_Per"; 
 
Performance{2,2} = min(GDRO_Per);           % Minimum_GDRO_Performance 
Performance{3,2} = min(DRO_Per);            % Minimum_DRO_Performance
Performance{4,2} = min(SAA_Per);            % Minimum_SO_Performance
Performance{5,2} = min(Deter_Per);          % Minimum_Deter_Performance 

Performance{2,3} = prctile(GDRO_Per,25);    % 25%_GDRO_Performance 
Performance{3,3} = prctile(DRO_Per,25);     % 25%_DRO_Performance
Performance{4,3} = prctile(SAA_Per,25);     % 25%_SO_Performance
Performance{5,3} = prctile(Deter_Per,25);   % 25%_Deter_Performance 

Performance{2,4} = mean(GDRO_Per);          % Mean_GDRO_Performance 
Performance{3,4} = mean(DRO_Per);           % Mean_DRO_Performance
Performance{4,4} = mean(SAA_Per);           % Mean_SO_Performance
Performance{5,4} = mean(Deter_Per);         % Mean_Deter_Performance 

Performance{2,5} = prctile(GDRO_Per,75);     % 75%_GDRO_Performance 
Performance{3,5} = prctile(DRO_Per,75);      % 75%_DRO_Performance
Performance{4,5} = prctile(SAA_Per,75);      % 75%_SO_Performance
Performance{5,5} = prctile(Deter_Per,75);    % 75%_Deter_Performance 

Performance{2,6} = max(GDRO_Performance);   % Worst_GDRO_Performance 
Performance{3,6} = max(DRO_Performance);    % Worst_DRO_Performance
Performance{4,6} = max(SAA_Performance);    % Worst_SO_Performance
Performance{5,6} = max(Deter_Performance);  % Worst_Deter_Performance 

Performance{2,7} = GDRO_Shortage_Count/(Size*Period*Retailer);    % Shortage_rate_GDRO
Performance{3,7} = DRO_Shortage_Count/(Size*Period*Retailer);     % Shortage_rate_DRO
Performance{4,7} = SAA_Shortage_Count/(Size*Period*Retailer);     % Shortage_rate_SO
Performance{5,7} = Deter_Shortage_Count/(Size*Period*Retailer);   % Shortage_rate_Deter

Performance{2,8} = GDRO_Violation_Count/(Size*Retailer);          % Violation_rate_GDRO
Performance{3,8} = DRO_Violation_Count/(Size*Retailer);           % Violation_rate_DRO
Performance{4,8} = SAA_Violation_Count/(Size*Retailer);           % Violation_rate_SO
Performance{5,8} = Deter_Violation_Count/(Size*Retailer);         % Violation_rate_Deter

% CVaR % CVaR  % CVaR  % CVaR  % CVaR  % CVaR  % CVaR  % CVaR  % CVaR    
Performance{2,9} = calculateRiskMetrics(GDRO_Per, 0.9);
Performance{3,9} = calculateRiskMetrics(DRO_Per, 0.9); 
Performance{4,9} = calculateRiskMetrics(SAA_Per, 0.9);   
Performance{5,9} = calculateRiskMetrics(Deter_Per, 0.9); 