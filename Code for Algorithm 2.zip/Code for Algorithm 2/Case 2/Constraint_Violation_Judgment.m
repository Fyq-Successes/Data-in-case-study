function [Result] = Constraint_Violation_Judgment(T,C,ch,cp,q,I0,d,tau)

Performance = zeros(1);                 
I = zeros(T,1);                         
Inventory_at_start_period = zeros(T,1); 
Result = 0;  

if I0 + q(1) > C
   Inventory_at_start_period(1,1) = C; 
else  
   Inventory_at_start_period(1,1) = I0 + q(1);
end 
I(1,1) = Inventory_at_start_period(1,1) - d(1); 

for t = 2:1:T 
    if I(t-1,1) + q(t) > C
        Inventory_at_start_period(t,1) = C; 
    else  
        Inventory_at_start_period(t,1) = I(t-1,1) + q(t);
    end
    I(t,1) = Inventory_at_start_period(t,1) - d(t);    
end

for t = 1:1:T
    if (I(t,1) > 0 && I(t,1) <= C) 
	    Performance = Performance + ch * I(t,1);
    end 
        
    if (I(t,1) > 0 && I(t,1) > C) 
        I(t,1) = C; 
		Performance = Performance + ch * I(t,1);
    end
 
    if (I(t,1) < 0) 
		Performance = Performance - cp * I(t,1); 
    end
end

if Performance > tau
   Result = 1; 
end

end
