%% 
subplot(1, 3, 1); 
[f_Deter,Deter] = ksdensity(Deter_Performance);      
plot(Deter,f_Deter,'->','MarkerSize',6,'color',[0.3 0.75 0.93],'LineWidth',1.5); 
hold on;  
[f_SO,SO] = ksdensity(SO_Performance);      
plot(SO,f_SO,'-p','MarkerSize',6,'color',[0.44 0.64 0.16],'LineWidth',1.5); 
hold on;  
[f_DRO1,DRO1] = ksdensity(DRO1_Performance); 
plot(DRO1,f_DRO1,'-*','MarkerSize',6,'color',[0 0.45 0.74],'LineWidth',1.5); 
hold on; 
[f_GDRO,GDRO] = ksdensity(GDRO_Performance);  
plot(GDRO,f_GDRO,'-v','MarkerSize',6,'color',[1 0.41 0.16],'LineWidth',1.5); 
hold on; 
xlabel('Total cost','FontSize',22);
ylabel('Probability density','FontSize',22);
set(gca,'XLim',[1*10^4 7*10^4]);
set(gca,'XTick', [1*10^4: 1.2*10^4 : 7*10^4]);
set(gca,'YLim',[0 0.9*10^(-4)]);
set(gca,'YTick', [0: 0.18*10^(-4) : 0.9*10^(-4)]);
grid on;
legend({'Deter-IRP','S-IRP-1','DR-IRP','GDR-IRP'});

%% 
subplot(1, 3, 2); 
X = 1:1:4;
GDR_IRP_SR = Performance{2,7}*10^2;
DR_IRP_SR = Performance{3,7}*10^2;
SO_IRP_SR = Performance{4,7}*10^2;
Deter_IRP_SR = Performance{5,7}*10^2;
OSR = [GDR_IRP_SR DR_IRP_SR SO_IRP_SR Deter_IRP_SR]; 
for i = 1:1:length(OSR)
    h = bar(X(i),OSR(i));
    if OSR(i) == GDR_IRP_SR
        set(h,'FaceColor',[1 0.41 0.16]);
    end
    if OSR(i) == DR_IRP_SR
        set(h,'FaceColor',[0 0.45 0.74]);
    end
    if OSR(i) == SO_IRP_SR 
        set(h,'FaceColor',[0.44 0.64 0.16]);
    end
    if OSR(i) == Deter_IRP_SR
        set(h,'FaceColor',[0.3 0.75 0.93]);
    end
    hold on
end

xlabel('Model','FontSize',22);
ylabel('OSR (%)','FontSize',22)
set(gca,'XLim',[0 5]);      
set(gca,'XTick',0:1:5);
set(gca,'YLim',[62 90]);
set(gca,'YTick',[62:5.6:90]);
grid on;
set(gca,'xticklabel',{'','GDR-IRP','DR-IRP','S-IRP','Deter-IRP',''}); 

%% 
subplot(1, 3, 3); 
X = 1:1:4;
GDR_IRP_BVR = Performance{2,8}*10^2;
DR_IRP_BVR = Performance{3,8}*10^2;
SO_IRP_BVR = Performance{4,8}*10^2;
Deter_IRP_BVR = Performance{5,8}*10^2;
BVR = [GDR_IRP_BVR DR_IRP_BVR SO_IRP_BVR Deter_IRP_BVR];
for i = 1:1:length(BVR)
    h = bar(X(i),BVR(i));
    if BVR(i) == GDR_IRP_BVR
        set(h,'FaceColor',[1 0.41 0.16]);
    end
    if BVR(i) == DR_IRP_BVR
        set(h,'FaceColor',[0 0.45 0.74]);
    end
    if BVR(i) == SO_IRP_BVR 
        set(h,'FaceColor',[0.44 0.64 0.16]);
    end
    if BVR(i) == Deter_IRP_BVR
        set(h,'FaceColor',[0.3 0.75 0.93]);
    end
    hold on
end

xlabel('Model','FontSize',22);
ylabel('BVR (%)','FontSize',22)
set(gca,'XLim',[0 5]);      
set(gca,'XTick',0:1:5);
set(gca,'YLim',[60 105]);
set(gca,'YTick',[60:9:105]);
grid on;
set(gca,'xticklabel',{'','GDR-IRP','DR-IRP','S-IRP','Deter-IRP',''}); 
