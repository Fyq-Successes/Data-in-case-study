function [CVaR] = calculateRiskMetrics(costs, confidence_level) 
 
    sorted_costs = sort(costs);
 
    num_costs = length(sorted_costs);
    var_index = round((1 - confidence_level) * num_costs);
 
    VaR = sorted_costs(end - var_index + 1); 
   
    if var_index == num_costs
        CVaR = NaN;
    else
        cvar_values = sorted_costs(end - var_index + 2:end); 
        CVaR = mean(cvar_values);
    end
 
end