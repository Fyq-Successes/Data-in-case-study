%% 
Period = 3;      
Retailer = 10;  
I0 = xlsread('Experimental_data.xlsx','Data','B3:K3');              
C = xlsread('Experimental_data.xlsx','Data','B7:K7');              
max_Demand = xlsread('Experimental_data.xlsx','Data','B11:K11');   
min_Demand = xlsread('Experimental_data.xlsx','Data','B15:K15'); 
ch = xlsread('Experimental_data.xlsx','Data','B19:K19');         
cp = xlsread('Experimental_data.xlsx','Data','B23:K23');           
Initial_inventory_cost = sum(I0.*cp);                          
%%   
GDRO_Trans_Cost = xlsread('Experimental_data.xlsx','Data','F26'); 
DRO1_Trans_Cost = xlsread('Experimental_data.xlsx','Data','I26'); 
SO_Trans_Cost = xlsread('Experimental_data.xlsx','Data','L26');     
Deter_Trans_Cost = xlsread('Experimental_data.xlsx','Data','O26'); 

GDRO_Q = xlsread('Experimental_data.xlsx','Data','B34:K36');
DRO1_Q = xlsread('Experimental_data.xlsx','Data','B39:K41'); 
SO_Q = xlsread('Experimental_data.xlsx','Data','B44:K46');          
Deter_Q = xlsread('Experimental_data.xlsx','Data','B49:K51');

GDRO_tau = xlsread('Experimental_data.xlsx','Data','B57:K57'); 
DRO1_tau = xlsread('Experimental_data.xlsx','Data','B60:K60'); 
SO_tau = xlsread('Experimental_data.xlsx','Data','B63:K63');      
Deter_tau = xlsread('Experimental_data.xlsx','Data','B66:K66'); 

%% 
Theta = 0.2;      
Size = 3000;    
Demand_data_set = zeros(Period,Retailer);    

%% 
GDRO_Performance = zeros(Size,1);
DRO1_Performance = zeros(Size,1);
SO_Performance = zeros(Size,1);
Deter_Performance = zeros(Size,1);

%  
GDRO_Shortage_Count = zeros(1);
DRO1_Shortage_Count = zeros(1);
SO_Shortage_Count = zeros(1);
Deter_Shortage_Count = zeros(1);

%  
GDRO_Violation_Count = zeros(1);
DRO1_Violation_Count = zeros(1);
SO_Violation_Count = zeros(1);
Deter_Violation_Count = zeros(1);

%% 
for s = 1:1:Size  
    for t = 1:1:Period
        for j = 1:1:Retailer 
           a = 3;
           b = 2;
           Demand_data_set(t,j) = fix( (max_Demand(j)*(1+Theta) - min_Demand(j)*(1-Theta)) .* betarnd(a, b) + min_Demand(j)*(1-Theta) ); 
        end 
    end 
    
    [GDRO_I,GDRO_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,GDRO_Trans_Cost,Period,Retailer,C,ch,cp,GDRO_Q,I0,Demand_data_set);
    [DRO1_I,DRO1_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,DRO1_Trans_Cost,Period,Retailer,C,ch,cp,DRO1_Q,I0,Demand_data_set);
    [SO_I,SO_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,SO_Trans_Cost,Period,Retailer,C,ch,cp,SO_Q,I0,Demand_data_set);   
    [Deter_I,Deter_Performance(s,1)] =  Function_Performance(Initial_inventory_cost,Deter_Trans_Cost,Period,Retailer,C,ch,cp,Deter_Q,I0,Demand_data_set);
    
    % Counting stock-outs 
    for t = 1:1:Period
        for j = 1:1:Retailer 
            if GDRO_I(t,j) < 0.01 
               GDRO_Shortage_Count = GDRO_Shortage_Count + 1; 
            end
            if DRO1_I(t,j) < 0.01 
               DRO1_Shortage_Count = DRO1_Shortage_Count + 1; 
            end
            if SO_I(t,j) < 0.01 
               SO_Shortage_Count = SO_Shortage_Count + 1; 
            end
            if Deter_I(t,j) < 0.01 
               Deter_Shortage_Count = Deter_Shortage_Count + 1; 
            end 
        end 
    end
    
    % Counting budget violations 
    for j = 1:1:Retailer
        [GDRO_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),GDRO_Q(:,j),I0(j),Demand_data_set(:,j),GDRO_tau(j));
        [DRO1_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),DRO1_Q(:,j),I0(j),Demand_data_set(:,j),DRO1_tau(j));
        [SO_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),SO_Q(:,j),I0(j),Demand_data_set(:,j),SO_tau(j)); 
        [Deter_Result] = Constraint_Violation_Judgment(Period,C(j),ch(j),cp(j),Deter_Q(:,j),I0(j),Demand_data_set(:,j),Deter_tau(j));
         
        if GDRO_Result == 1
            GDRO_Violation_Count = GDRO_Violation_Count + 1; 
        end    
        if DRO1_Result == 1
            DRO1_Violation_Count = DRO1_Violation_Count + 1; 
        end
        if SO_Result == 1
            SO_Violation_Count = SO_Violation_Count + 1; 
        end
        if Deter_Result == 1
            Deter_Violation_Count = Deter_Violation_Count + 1; 
        end   
    end 
    
end 
  
GDRO_Per = sort(GDRO_Performance);
DRO1_Per = sort(DRO1_Performance);   
SO_Per = sort(SO_Performance); 
Deter_Per = sort(Deter_Performance);

Performance = cell(5,9); 

Performance{1,2} = "Minimum";
Performance{1,3} = "25th %";
Performance{1,4} = "Average";
Performance{1,5} = "75th %";
Performance{1,6} = "Maximum";
Performance{1,7} = "Shortage_Rate";
Performance{1,8} = "Budget_Valation_Rate";
Performance{1,9} = "CVaR";

Performance{2,1} = "GDRO_IRP_Per";
Performance{3,1} = "DRO1_IRP_Per";
Performance{4,1} = "SO_IRP_Per";  
Performance{5,1} = "Deter_IRP_Per"; 

% minimum 
Performance{2,2} = min(GDRO_Per);             % Minimum_GDRO_Performance 
Performance{3,2} = min(DRO1_Per);             % Minimum_DRO1_Performance
Performance{4,2} = min(SO_Per);               % Minimum_SO_Performance
Performance{5,2} = min(Deter_Per);            % Minimum_Deter_Performance 

% 25%
Performance{2,3} = prctile(GDRO_Per,25);      
Performance{3,3} = prctile(DRO1_Per,25);      
Performance{4,3} = prctile(SO_Per,25);       
Performance{5,3} = prctile(Deter_Per,25);     

% Mean
Performance{2,4} = mean(GDRO_Per);            % Mean_GDRO_Performance 
Performance{3,4} = mean(DRO1_Per);            % Mean_DRO1_Performance
Performance{4,4} = mean(SO_Per);              % Mean_SO_Performance
Performance{5,4} = mean(Deter_Per);           % Mean_Deter_Performance 

% 75%
Performance{2,5} = prctile(GDRO_Per,75);      
Performance{3,5} = prctile(DRO1_Per,75);      
Performance{4,5} = prctile(SO_Per,75);        
Performance{5,5} = prctile(Deter_Per,75);    

% Worst case
Performance{2,6} = max(GDRO_Per);     % Worst_GDRO_Performance 
Performance{3,6} = max(DRO1_Per);     % Worst_DRO1_Performance
Performance{4,6} = max(SO_Per);       % Worst_SO_Performance
Performance{5,6} = max(Deter_Per);    % Worst_Deter_Performance 

% 
Performance{2,7} = GDRO_Shortage_Count/(Size*Period*Retailer);      % Shortage_rate_GDRO
Performance{3,7} = DRO1_Shortage_Count/(Size*Period*Retailer);      % Shortage_rate_DRO1
Performance{4,7} = SO_Shortage_Count/(Size*Period*Retailer);        % Shortage_rate_SO
Performance{5,7} = Deter_Shortage_Count/(Size*Period*Retailer);     % Shortage_rate_Deter

% 
Performance{2,8} = GDRO_Violation_Count/(Size*Retailer);            % Violation_rate_GDRO
Performance{3,8} = DRO1_Violation_Count/(Size*Retailer);            % Violation_rate_DRO1
Performance{4,8} = SO_Violation_Count/(Size*Retailer);              % Violation_rate_SO
Performance{5,8} = Deter_Violation_Count/(Size*Retailer);           % Violation_rate_Deter

% CVaR     
Performance{2,9} = calculateRiskMetrics(GDRO_Per, 0.9);
Performance{3,9} = calculateRiskMetrics(DRO1_Per, 0.9); 
Performance{4,9} = calculateRiskMetrics(SO_Per, 0.9);   
Performance{5,9} = calculateRiskMetrics(Deter_Per, 0.9);