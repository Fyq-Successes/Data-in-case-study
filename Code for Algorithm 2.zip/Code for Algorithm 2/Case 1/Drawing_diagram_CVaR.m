Confidence_level = 0.9; 

Deter_model_sorted_Data = sort(Deter_Per);
SO_model_sorted_Data = sort(SO_Per);
DRO1_model_sorted_Data = sort(DRO1_Per);
GDRO_model_sorted_Data = sort(GDRO_Per);

Deter_number = length(Deter_model_sorted_Data);
Deter_VaR_Index = round((1 - Confidence_level) * Deter_number);
SAA_number = length(SO_model_sorted_Data);
SAA_VaR_Index = round((1 - Confidence_level) * SAA_number);
DRO_number = length(DRO1_model_sorted_Data);
DRO_VaR_Index = round((1 - Confidence_level) * DRO_number);
GDRO_number = length(GDRO_model_sorted_Data);
GDRO_VaR_Index = round((1 - Confidence_level) * GDRO_number);

Deter_VaR_Value = Deter_model_sorted_Data(end - Deter_VaR_Index + 1);
SO_VaR_Value = SO_model_sorted_Data(end - SAA_VaR_Index + 1);
DRO_VaR_Value = DRO1_model_sorted_Data(end - DRO_VaR_Index + 1);
GDRO_VaR_Value = GDRO_model_sorted_Data(end - GDRO_VaR_Index + 1);

Deter_filteredData = Deter_model_sorted_Data(end - Deter_VaR_Index + 2:end);
SO_filteredData = SO_model_sorted_Data(end - SAA_VaR_Index + 2:end);
DRO_filteredData = DRO1_model_sorted_Data(end - DRO_VaR_Index + 2:end);
GDRO_filteredData = GDRO_model_sorted_Data(end - GDRO_VaR_Index + 2:end);

Deter_CVaR = mean(Deter_filteredData); 
SO_CVaR = mean(SO_filteredData); 
DRO_CVaR = mean(DRO_filteredData); 
GDRO_CVaR = mean(GDRO_filteredData); 

Deter = plot([121 121], [Deter_CVaR Deter_CVaR],'d','MarkerSize',10,'color',[0.3 0.75 0.93],'LineWidth',1.6);
hold on; 
SO = plot([123 123], [SO_CVaR SO_CVaR],'p','MarkerSize',10,'color',[0.44 0.64 0.16],'LineWidth',1.6);
hold on; 
DRO = plot([121 121], [DRO_CVaR DRO_CVaR],'*','MarkerSize',10,'color',[0 0.45 0.74],'LineWidth',1.6);
hold on; 
GDRO = plot([120 120], [GDRO_CVaR GDRO_CVaR],'v','MarkerSize',10,'color',[1 0.41 0.16],'LineWidth',1.6);
hold on; 
plot(1:1:length(Deter_filteredData), sort(Deter_filteredData, 'descend'),'-','color',[0.3 0.75 0.93],'LineWidth',1.2);
hold on; 
plot(1:1:length(SO_filteredData),sort(SO_filteredData, 'descend'),'-','color',[0.44 0.64 0.16],'LineWidth',1.2); 
hold on; 
plot(1:1:length(DRO_filteredData),sort(DRO_filteredData, 'descend'),'-','color',[0 0.45 0.74],'LineWidth',1.2); 
hold on; 
plot(1:1:length(GDRO_filteredData),sort(GDRO_filteredData, 'descend'),'-','color',[1 0.41 0.16],'LineWidth',1.2); 
ylabel('The cost of exceeding the VaR','FontSize',24);
grid on; 
legend([Deter SO DRO GDRO],'CVaR of Deter-IRP model','CVaR of S-IRP','CVaR of DR-IRP','CVaR of GDR-IRP');
